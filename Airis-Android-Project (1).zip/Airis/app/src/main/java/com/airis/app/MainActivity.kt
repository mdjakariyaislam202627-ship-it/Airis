package com.airis.app

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.provider.MediaStore
import android.provider.Settings
import android.net.Uri
import android.os.Bundle
import android.provider.AlarmClock
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Date
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var tts: TextToSpeech
    private lateinit var log: TextView
    private lateinit var scroll: ScrollView
    private lateinit var input: EditText
    private var sr: SpeechRecognizer? = null
    private val hist = JSONArray()
    private val bn = Locale("bn", "BD")

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        tts = TextToSpeech(this, this)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 48, 24, 24) }
        val title = TextView(this).apply { text = "Airis • আইরিস"; textSize = 22f; gravity = Gravity.CENTER }
        title.setOnLongClickListener { askKey(); true }
        scroll = ScrollView(this)
        log = TextView(this).apply { textSize = 17f; setPadding(8, 8, 8, 8) }
        scroll.addView(log)
        val mic = Button(this).apply { text = "🎤 বলুন" ; textSize = 20f }
        mic.setOnClickListener { listen() }
        input = EditText(this).apply { hint = "অথবা এখানে লিখুন" }
        val send = Button(this).apply { text = "পাঠান" }
        send.setOnClickListener { handle(input.text.toString()); input.setText("") }
        root.addView(title, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        root.addView(scroll, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))
        root.addView(mic, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        root.addView(input, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        root.addView(send, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        setContentView(root)
        requestPermissions(arrayOf(android.Manifest.permission.RECORD_AUDIO), 1)
        say("আমি আইরিস, আপনার সহকারী। বলুন, কী করতে পারি?")
        if (key().isEmpty()) askKey()
    }

    override fun onInit(s: Int) { if (s == TextToSpeech.SUCCESS) tts.language = bn }

    private fun key() = getSharedPreferences("a", 0).getString("k", "") ?: ""

    private fun askKey() {
        val e = EditText(this).apply { hint = "sk-ant-..." }
        AlertDialog.Builder(this).setTitle("Anthropic API key").setView(e)
            .setPositiveButton("সেভ") { _, _ -> getSharedPreferences("a", 0).edit().putString("k", e.text.toString().trim()).apply() }
            .show()
    }

    private fun show(who: String, t: String) { runOnUiThread { log.append("$who: $t\n\n"); scroll.post { scroll.fullScroll(ScrollView.FOCUS_DOWN) } } }
    private fun say(t: String) { show("আইরিস", t); tts.speak(t, TextToSpeech.QUEUE_FLUSH, null, "x") }

    private fun listen() {
        tts.stop()
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { say("এই ফোনে ভয়েস ইনপুট নেই।"); return }
        sr?.destroy()
        sr = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onResults(r: Bundle) { r.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let { handle(it) } }
                override fun onError(e: Int) { say("শুনতে পাইনি, আবার বলুন।") }
                override fun onReadyForSpeech(p: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(p: Bundle?) {}
                override fun onEvent(t: Int, p: Bundle?) {}
            })
            startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "bn-BD")
                putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            })
        }
    }

    private fun digits(s: String) = s.map { c -> if (c in '০'..'৯') ('0' + (c - '০')) else c }.joinToString("")

    private fun openApp(pkg: String, name: String): Boolean {
        val i = packageManager.getLaunchIntentForPackage(pkg)
        return if (i != null) { startActivity(i); say("$name খুলছি।"); true } else { say("$name ফোনে নেই।"); true }
    }

    private fun go(i: Intent, msg: String): Boolean {
        try { startActivity(i); say(msg) } catch (e: Exception) { say("এটা খুলতে পারলাম না।") }
        return true
    }

    private var torchOn = false
    private fun torch(on: Boolean) {
        try {
            val cm = getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val id = cm.cameraIdList.firstOrNull { cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
            if (id == null) { say("এই ফোনে ফ্ল্যাশ নেই।"); return }
            cm.setTorchMode(id, on); torchOn = on
            say(if (on) "টর্চ জ্বালালাম।" else "টর্চ নেভালাম।")
        } catch (e: Exception) { say("টর্চ চালাতে পারলাম না।") }
    }

    private fun online(): Boolean {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val n = cm.activeNetwork ?: return false
        return cm.getNetworkCapabilities(n)?.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) == true
    }

    private fun local(q: String): Boolean {
        val s = digits(q.lowercase())
        when {
            s.contains("সময়") -> { say(java.text.SimpleDateFormat("h:mm a", bn).format(Date()) + " বাজে।"); return true }
            s.contains("তারিখ") -> { say("আজ " + java.text.DateFormat.getDateInstance(java.text.DateFormat.FULL, bn).format(Date())); return true }
            s.contains("হোয়াটসঅ্যাপ") || s.contains("whatsapp") -> return openApp("com.whatsapp", "হোয়াটসঅ্যাপ")
            s.contains("ইউটিউব") || s.contains("youtube") -> return openApp("com.google.android.youtube", "ইউটিউব")
            s.contains("ফেসবুক") -> return openApp("com.facebook.katana", "ফেসবুক")
            s.contains("ব্যাটারি") -> {
                val bm = getSystemService(Context.BATTERY_SERVICE) as BatteryManager
                say("ব্যাটারি ${bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)} শতাংশ আছে।"); return true
            }
            s.contains("টর্চ") || s.contains("ফ্ল্যাশলাইট") -> { torch(!(s.contains("নেভা") || s.contains("বন্ধ"))); return true }
            s.contains("ক্যামেরা") -> return go(Intent(MediaStore.ACTION_IMAGE_CAPTURE), "ক্যামেরা খুলছি।")
            s.contains("ওয়াইফাই") -> return go(Intent(Settings.ACTION_WIFI_SETTINGS), "ওয়াইফাই সেটিংস খুলছি।")
            s.contains("ব্লুটুথ") -> return go(Intent(Settings.ACTION_BLUETOOTH_SETTINGS), "ব্লুটুথ সেটিংস খুলছি।")
            s.contains("সাহায্য") || s.contains("কী করতে পারো") || s.contains("কি করতে পারো") -> {
                say("ইন্টারনেট ছাড়াও আমি সময়, তারিখ, ব্যাটারি, টর্চ, ক্যামেরা, অ্যালার্ম, কল আর অ্যাপ খোলা পারি। ইন্টারনেট থাকলে যেকোনো প্রশ্নের উত্তর দিই।"); return true
            }
            s.contains("অ্যালার্ম") || s.contains("এলার্ম") -> {
                val n = Regex("\\d+").findAll(s).map { it.value.toInt() }.toList()
                if (n.isEmpty()) { say("কয়টায় অ্যালার্ম দেব?"); return true }
                var h = n[0]; val m = n.getOrElse(1) { 0 }
                if ((s.contains("বিকাল") || s.contains("সন্ধ্যা") || s.contains("রাত")) && h < 12) h += 12
                startActivity(Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_HOUR, h).putExtra(AlarmClock.EXTRA_MINUTES, m))
                say("অ্যালার্ম সেট করছি।"); return true
            }
            s.contains("কল") -> {
                val num = Regex("\\+?\\d[\\d ]{5,}").find(s)?.value?.replace(" ", "")
                if (num != null) { startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$num"))); say("$num নম্বরে কল করছি।"); return true }
            }
        }
        return false
    }

    private fun handle(q: String) {
        val t = q.trim(); if (t.isEmpty()) return
        show("আপনি", t)
        if (local(t)) return
        if (!online()) { say("ইন্টারনেট নেই, তাই এই প্রশ্নের উত্তর দিতে পারছি না। তবে সময়, ব্যাটারি, টর্চ, অ্যালার্ম, কল বা অ্যাপ খোলা বলতে পারেন।"); return }
        if (key().isEmpty()) { askKey(); return }
        hist.put(JSONObject().put("role", "user").put("content", t))
        Thread {
            try {
                val body = JSONObject().put("model", "claude-sonnet-5-5").put("max_tokens", 600)
                    .put("system", "তোমার নাম আইরিস। তুমি ব্যবহারকারীর ব্যক্তিগত সহকারী। সবসময় সহজ বাংলায়, ছোট করে উত্তর দাও।")
                    .put("messages", hist)
                val c = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
                c.requestMethod = "POST"; c.doOutput = true
                c.setRequestProperty("x-api-key", key())
                c.setRequestProperty("anthropic-version", "2023-06-01")
                c.setRequestProperty("content-type", "application/json")
                c.outputStream.use { it.write(body.toString().toByteArray()) }
                val txt = (if (c.responseCode in 200..299) c.inputStream else c.errorStream).bufferedReader().readText()
                val ans = JSONObject(txt).getJSONArray("content").getJSONObject(0).getString("text")
                hist.put(JSONObject().put("role", "assistant").put("content", ans))
                runOnUiThread { say(ans) }
            } catch (e: Exception) {
                hist.remove(hist.length() - 1)
                runOnUiThread { say("দুঃখিত, সংযোগে সমস্যা হয়েছে।") }
            }
        }.start()
    }
}
